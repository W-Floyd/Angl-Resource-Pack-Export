# Angl-Resource-Pack
##An open-source vector based Minecraft resource pack.
***
####This pack was exported:
2016-10-20_17-23-30
***
####This pack was rendered at:
256x256px
***

To download the resource pack, look here: https://github.com/W-Floyd/Angl-Resource-Pack-Export

***

This pack is based on vector graphics and compositing.
This is accomplished with a combination of inkscape and bash scripts.
As such, any modifications should only be made to the source vector files, not the exported raster files.

While the work is open source, this is primarily for the enjoyment of others.
You may view the source at https://github.com/W-Floyd/Angl-Resource-Pack

Open source doesn't mean you can do whatever you want with it.
Follow common etiquette - this is my work, don't steal. Or 'borrow'.

The script system, however, is fair game.

***

(c) William Floyd - 2016
